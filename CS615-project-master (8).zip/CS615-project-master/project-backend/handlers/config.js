module.exports = {
  secret: "bindukarthiksiddhu",
};
